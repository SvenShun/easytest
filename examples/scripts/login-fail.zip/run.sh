#!/bin/sh

OUT="${TESTHUB_OUTPUT_DIR:-./output}"
mkdir -p "$OUT"
echo "[demo] device=$TESTHUB_DEVICE_SERIAL task=$TESTHUB_TASK_ID"
echo "[demo] case: 用户使用错误凭据登录应提示错误"
cat > "$OUT/junit.xml" <<'XML'
<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="com.testhub.demo.LoginErrorTest" tests="2" failures="1" errors="0" time="4.1">
  <testcase classname="com.testhub.demo.LoginErrorTest" name="openLoginPage" time="1.0"/>
  <testcase classname="com.testhub.demo.LoginErrorTest" name="loginShowsErrorToast" time="3.1">
    <failure message="expected toast 用户名或密码错误 but was 登录成功">AssertionError: expected toast</failure>
  </testcase>
</testsuite>
XML
printf '%s' 'iVBORw0KGgoAAAANSUhEUgAAAWgAAACWCAIAAAB8aIVfAAABxElEQVR42u3boQ3AMAxFwWwQ2B1CslRZabbIlkGB3aCVukGhrZNuAoOHvks9GsAvxQkA4QCEAxAOQDgA4QAQDkA4AOEAhAMQDgDhAIQDEA5AOADhABAOQDgA4QDShqNfDxCUcADCAQgHIBzCAcIhHCAcwgEIByAcgHAAwiEcIBzCAQgHIByAcADCIRwgHMIBCAcgHIBwAMIhHCAcwgHCIRyAcADCAQiHcIBwAAgHIByAcADCAQgHgHAAwgEIByAcgHAACAcgHIBwAMIBCAeAcADCAUQIx9o3EJRwAMIBCAcgHMIBwiEcIBzCAQgHIByAcADCASAcgHAAwgEIByAcAMIBCAcgHIBwAMIBIByAcADCAWQNxzkm5KAFwgHCIRwgHMIBwiEcIBzCIRwIB8IBwiEcIBwGYIBwAMIBIByAcADCAQgHIBwAwgEIByAcgHAAwvHxGYVvMeEQDoQD4UA4EA6EA+FAOBAOEA7hEA6EA+FAODAAA4QDEA5AOACEAxAOQDgA4QCEAxAOVwCEAxAOQDgA4QCEA0A4AOEAhAMQDkA4AIQDEA5AOADhAIQDQDgA4QCEAxAOQDgA4QAQDkA4AOEAgnsB8ADk8tnTAB8AAAAASUVORK5CYII=' | base64 -d > "$OUT/screenshot.png"
echo "[demo] screenshot saved: $OUT/screenshot.png"
echo "[demo] assertion failed: expected toast 用户名或密码错误 but was 登录成功"; exit 1
