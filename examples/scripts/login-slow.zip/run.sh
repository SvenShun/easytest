#!/bin/sh
set -e
OUT="${TESTHUB_OUTPUT_DIR:-./output}"
mkdir -p "$OUT"
echo "[demo] device=$TESTHUB_DEVICE_SERIAL task=$TESTHUB_TASK_ID"
echo "[demo] case: 用户登录（慢速回归用例）"
cat > "$OUT/junit.xml" <<'XML'
<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="com.testhub.demo.SlowLoginTest" tests="1" failures="0" errors="0" time="6.0">
  <testcase classname="com.testhub.demo.SlowLoginTest" name="loginSlowly" time="6.0"/>
</testsuite>
XML
printf '%s' 'iVBORw0KGgoAAAANSUhEUgAAAWgAAACWCAIAAAB8aIVfAAABxElEQVR42u3boQ3AMAxFwWwQ2B1CslRZabbIlkGB3aCVukGhrZNuAoOHvks9GsAvxQkA4QCEAxAOQDgA4QAQDkA4AOEAhAMQDgDhAIQDEA5AOADhABAOQDgA4QDShqNfDxCUcADCAQgHIBzCAcIhHCAcwgEIByAcgHAAwiEcIBzCAQgHIByAcADCIRwgHMIBCAcgHIBwAMIhHCAcwgHCIRyAcADCAQiHcIBwAAgHIByAcADCAQgHgHAAwgEIByAcgHAACAcgHIBwAMIBCAeAcADCAUQIx9o3EJRwAMIBCAcgHMIBwiEcIBzCAQgHIByAcADCASAcgHAAwgEIByAcAMIBCAcgHIBwAMIBIByAcADCAWQNxzkm5KAFwgHCIRwgHMIBwiEcIBzCIRwIB8IBwiEcIBwGYIBwAMIBIByAcADCAQgHIBwAwgEIByAcgHAAwvHxGYVvMeEQDoQD4UA4EA6EA+FAOBAOEA7hEA6EA+FAODAAA4QDEA5AOACEAxAOQDgA4QCEAxAOVwCEAxAOQDgA4QCEA0A4AOEAhAMQDkA4AIQDEA5AOADhAIQDQDgA4QCEAxAOQDgA4QAQDkA4AOEAgnsB8ADk8tnTAB8AAAAASUVORK5CYII=' | base64 -d > "$OUT/screenshot.png"
echo "[demo] screenshot saved: $OUT/screenshot.png"
echo "[demo] sleeping 6s to make queue observable"; sleep 6; echo "[demo] done: 1 passed"
